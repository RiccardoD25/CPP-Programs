// Implementation file for the pet class
#include "pet.h"	// Needed for the pet class
#include<iostream> // Needed for the cout
#include<cstdlib> // Needed for the exit function
using namespace std;


